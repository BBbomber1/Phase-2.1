var inventory = [];

function Item(name, quantity, measurement, category, location, date_text, expiration) {
    this.name = name;
    this.quantity = quantity;
    this.measurement = measurement;
    this.category = category;
    this.location = location;
    this.date_text = date_text;
    this.expiration = expiration;
}

document.addEventListener("DOMContentLoaded", function() {
    // Reference to the keyboard images
    var keyboardImage = document.getElementById('keyboardImage');
    var formKeyboardImage = document.getElementById('formKeyboardImage');

    // Select all input fields
    const inputFields = document.querySelectorAll('input[type="text"], textarea');

    inputFields.forEach(field => {
        // Show the general keyboard image for all fields
        field.addEventListener('focus', () => {
            keyboardImage.style.display = 'block';
            // Check if the field is inside the forms that should show the formKeyboardImage
            if (field.closest("#editForm")) {
                formKeyboardImage.style.display = 'block';
            }
        });

        // Hide images on blur
        field.addEventListener('blur', () => {
            keyboardImage.style.display = 'none';
            // Additional check to hide formKeyboardImage might not be necessary if it's always paired with keyboardImage visibility
            formKeyboardImage.style.display = 'none';
        });
    });

    loadInventory();
});

function addItem() {
    document.getElementById("addForm").style.display = "block";
    
    resetForm();
}

function confirmAdd() {    
    var name = document.getElementById('name').value;
    var quantity = document.getElementById('quantity').value;
    var measurement = document.getElementById('unit').value;
    var category = document.getElementById('category').value;
    var location = document.getElementById('location').value;
    var date_text = document.getElementById('date-text').value;
    var expiration = document.getElementById('expiration').value;

    if (name != "" && quantity != "" && measurement != "" && category != "" && location != "" && date_text != "" && expiration != "") {
        var newItem = new Item(name, quantity, measurement, category, location, date_text, expiration);

        inventory.push(newItem);

        createHTML(newItem);

        saveInventory();
        
        document.getElementById("addForm").style.display = "none";

        var subwindow = document.getElementById("grid");

        // Scroll the div to the bottom
        subwindow.scrollTo({ top: 99999, behavior: 'smooth' });
    } 
}

function resetForm() {
    document.getElementById('name').value = "";
    document.getElementById('quantity').value = "";
    document.getElementById('unit').value = "";
    document.getElementById('category').value = "";
    document.getElementById('location').value = "";
    document.getElementById('date-text').value = "";
    document.getElementById('expiration').value = "";
}

function closeForm() {
    resetForm();

    document.getElementById("addForm").style.display = "none";
}

function updateSearch() {
    var name = document.getElementById('nameSearch').value;
    var category = document.getElementById('categorySearch').value;
    var location = document.getElementById('locationSearch').value;

    if (name == "" && category == "" && location == "") {
        deleteSearch()
        for (var item of inventory) {
            createHTML(item);
        }
    } else {
       deleteSearch()

        for (var item of inventory) {
            if (name.toLowerCase() == item.name.toLowerCase() || item.name.toLowerCase().includes(name.toLowerCase()) || name == "") {
                if (category.toLowerCase() == item.category.toLowerCase() || item.category.toLowerCase().includes(category.toLowerCase()) || category == "") {
                    if (location.toLowerCase() == item.location.toLowerCase() || item.location.toLowerCase().includes(location.toLowerCase()) || location == "") {
                        createHTML(item);
                    }
                }
            }
        }
    }
}

function clearSearchbox() {
    document.getElementById('nameSearch').value = "";
    document.getElementById('categorySearch').value = "";
    document.getElementById('locationSearch').value = "";

    deleteSearch()
    updateSearch()
}

function deleteSearch() {
    const parentElement = document.getElementById('grid');

    while (parentElement.firstChild) {
        parentElement.removeChild(parentElement.firstChild);
    }
}

function findItem(element) {
    itemName = element.querySelector('b').textContent;

    for (var item of inventory) {
        if (item.name == itemName) {
            return item;
        }
    }
}

function deleteItem(event) {
    event.stopPropagation();
    var parent = this.parentElement;

    currItem = findItem(parent);

    inventory.splice(inventory.indexOf(currItem), 1);

    saveInventory();

    parent.remove();
}

function inspectElement(element) {

    currItem = findItem(element);

    document.getElementById('editName').value = currItem.name;
    document.getElementById('editQuantity').value = currItem.quantity;
    document.getElementById('editUnit').value = currItem.measurement;
    document.getElementById('editCategory').value = currItem.category;
    document.getElementById('editLocation').value = currItem.location;
    document.getElementById('editDate-text').value = currItem.date_text;
    document.getElementById('editExpiration').value = currItem.expiration;

    document.getElementById('confirmButton').onclick = function() {
        confirmChanges(element, currItem);
    };

    document.getElementById("editForm").style.display = "block";
}

function confirmChanges(element, currItem) {
    

    var name = document.getElementById('editName').value;
    var quantity = document.getElementById('editQuantity').value;
    var measurement = document.getElementById('editUnit').value;
    var category = document.getElementById('editCategory').value;
    var location = document.getElementById('editLocation').value;
    var date_text = document.getElementById('editDate-text').value;
    var expiration = document.getElementById('editExpiration').value;

    if (name != "" && quantity != "" && measurement != "" && category != "" && location != "" && date_text != "" && expiration != "") {

        var newItem = new Item(name, quantity, measurement, category, location, date_text, expiration);

        inventory[inventory.indexOf(currItem)] = newItem;

        saveInventory();

        element.innerHTML = "<b>" + name + "</b> <br>" + 
        "Quantity: " + quantity + " " + measurement + " <br> " +
        "Category: " + category + "<br>" +
        "Location: " + location + "<br>" + 
        date_text + " " + expiration;

        const buttonElement = document.createElement('button');
        buttonElement.innerHTML = "<img src='img-recipe/trashcan.png' alt='Delete'>";
        buttonElement.classList.add('delete-button')
        buttonElement.onclick = deleteItem;   
        
        const buttonElement2 = document.createElement('button');
        buttonElement2.innerHTML = "<img src='img-fridge/pencil.png' alt='Edit'>";
        buttonElement2.classList.add('edit-button')

        element.appendChild(buttonElement);
        element.appendChild(buttonElement2);
        document.getElementById("editForm").style.display = "none";
    }
}

function closeEditForm() {
    document.getElementById("editForm").style.display = "none";
}

function createHTML(newItem) {
    const newElement = document.createElement('div');

        newElement.innerHTML = "<b>" + newItem.name + "</b> <br>" + 
                               "Quantity: " + newItem.quantity + " " + newItem.measurement + " <br> " +
                               "Category: " + newItem.category + "<br>" +
                               "Location: " + newItem.location + "<br>" +
                               newItem.date_text + " " + newItem.expiration;
        newElement.classList.add('grid-item');
        newElement.addEventListener('click', function() {
            inspectElement(this);
        });

        const parent = document.getElementById('grid');

        parent.appendChild(newElement);

        const buttonElement = document.createElement('button');
        buttonElement.innerHTML = "<img src='img-recipe/trashcan.png' alt='Delete'>";
        buttonElement.classList.add('delete-button')
        buttonElement.onclick = deleteItem;

        const buttonElement2 = document.createElement('button');
        buttonElement2.innerHTML = "<img src='img-fridge/pencil.png' alt='Edit'>";
        buttonElement2.classList.add('edit-button')

        newElement.appendChild(buttonElement);
        newElement.appendChild(buttonElement2);
}

function saveInventory() {
    localStorage.setItem('inventory', JSON.stringify(inventory));
}

function loadInventory() {
    var savedInventory = localStorage.getItem("inventory");

    inventory = JSON.parse(savedInventory);

    if (inventory != null) {
        for (var item of inventory) {
            createHTML(item);
        }
    } else {
        inventory = [];
    }
}