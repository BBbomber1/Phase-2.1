var recipes = [];

function Recipe(name, cookingLevel, ingredientsDescription, directionsDescription, cuisine, dietaryRestriction, favorite) {
    this.name = name;
    this.cookingLevel = cookingLevel
    this.ingredientsDescription = ingredientsDescription;
    this.directionsDescription = directionsDescription;
    this.cuisine = cuisine;
    this.dietaryRestriction = dietaryRestriction;
    this.favorite = favorite;

}

// Default recipes
var PadThai = new Recipe("Pad Thai", "Beginner", "Rice noodles, shrimp, chicken, peanuts, a scrambled egg and bean sprouts.", "Sautée ingredients together in a wok and toss in a delicious Pad Thai sauce.",
    "Thai", "None", true);
var margheritaPizza = new Recipe("Pepperoni Pizza", "Beginner", "Cheese, Pizza Dough, Pizza Sauce", "Roll out pizza dough and roll it out. Spread pizza sauce over dough and add cheese with pepperoni dishes. Place in oven set to 350 degrees Fahrenheit for 20 minutes. Enjoy!",
    "Italian", "Peanut-Free", false);



document.addEventListener("DOMContentLoaded", function() {
    loadRecipes();
    const searchInput = document.querySelector('.search-input');
    const searchButton = document.querySelector('.search-button');
    const cuisineDropdown = document.querySelector('.sort-dropdown');
    const dietaryDropdown = document.querySelector('.dietary-restriction-dropdown');
    const cookingDropdown = document.querySelector('.cooking-level-dropdown');
    var keyboardImage = document.getElementById('keyboardImage');
    var formKeyboardImage = document.getElementById('formKeyboardImage')
    const inputFields = document.querySelectorAll('input[type="text"], textarea');
    
    inputFields.forEach(field => {
        field.addEventListener('focus', () => {
            document.getElementById('keyboardImage').style.display = 'block';
            document.getElementById('formKeyboardImage').style.display = 'block'; // Step 3
        });

        // Optional: Hide the keyboard image on blur
        field.addEventListener('blur', () => {
            document.getElementById('keyboardImage').style.display = 'none';
            document.getElementById('formKeyboardImage').style.display = 'none';
        });
    });

    searchButton.addEventListener('click', () => searchRecipes(searchInput));
    searchInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            searchRecipes(searchInput);
        }
    }); 

    cuisineDropdown.addEventListener('change', filterRecipes);
    dietaryDropdown.addEventListener('change', filterRecipes);
    cookingDropdown.addEventListener('change', filterRecipes);
});

function searchRecipes(searchInput) {
    const searchText = searchInput.value.trim().toLowerCase();
    let matchFound = false; // Flag to track if any match is found

    if (searchText === '') {
        recipes.forEach((recipe, index) => {
            const recipeItem = document.querySelector(`[data-index="${index}"]`);
            if (recipeItem) {
                recipeItem.style.display = 'block';
            } else {
                console.log("Recipe item not found in DOM");
            }
        });
    } else {
        recipes.forEach((recipe, index) => {
            const recipeName = recipe.name.toLowerCase();
            const recipeItem = document.querySelector(`[data-index="${index}"]`);
            if (recipeItem) {
                if (recipeName == searchText) {
                    recipeItem.style.display = 'block';
                    matchFound = true; // Set flag to true if a match is found
                } else {
                    recipeItem.style.display = 'none';
                }
            } else {
                console.log("Recipe item not found in DOM");
            }
        });
    
        // Hide all recipes if no match is found
        if (!matchFound) {
            recipes.forEach((recipe, index) => {
                const recipeItem = document.querySelector(`[data-index="${index}"]`);
                if (recipeItem) {
                    recipeItem.style.display = 'none';
                }
            });
        }
    }

}

function loadRecipes() {
    console.log(recipes);
    var recipeList = document.querySelector(".recipe-list");
    recipeList.innerHTML = '';

    recipes.forEach(function(recipe, index) {
        var li = document.createElement("li");
        li.className = "recipe-item";
        li.setAttribute("data-index", index);
        li.setAttribute("data-food-type", recipe.cuisine);
        li.setAttribute("data-dietary-restriction-type", recipe.dietaryRestriction);
        li.setAttribute("data-cooking-type", recipe.cookingLevel)

        var favoriteImage = recipe.favorite ? "img-recipe/star-gold.png" : "img-recipe/star.png";

        li.innerHTML = `
            <h3>${recipe.name}</h3>
            <p><strong>Cooking Level:</strong> ${recipe.cookingLevel} </p>
            <p><strong>Cuisine Type:</strong> ${recipe.cuisine}</p>
            <p><strong>Dietary Restriction:</strong> ${recipe.dietaryRestriction}</p>
            <p><strong>Ingredients:</strong></p>
            <p>${recipe.ingredientsDescription}</p>
            <p><strong>Directions:</strong></p>
            <p>${recipe.directionsDescription}</p>
            <button type="button" class="delete-button" onclick="deleteRecipe(${index})"><img src="img-recipe/trashcan.png" alt="Delete"></button>
            <button type="button" class="favorite-button" onclick="toggleFavorite(${index})"><img src="${favoriteImage}" alt="Favorite Status"></button>
            <button type="button" class="shopping-list-button" onclick="goToShoppingListPage()"><img src="img-recipe/shopping-list-image.png" alt="Shopping List"></button>
        `;
        recipeList.appendChild(li);
    });
    filterRecipes();
}

function goToShoppingListPage() {
    window.location.href = "ShoppingList.html";
}

function deleteRecipe(index) {

        recipes.splice(index, 1); // Remove recipe from array
        loadRecipes(); // Refresh recipe list
        saveRecipes();
    
}

function toggleFavorite(index) {
    recipes[index].favorite = !recipes[index].favorite; // Toggle favorite status
    
    // Check if the recipe is now a favorite
    if (recipes[index].favorite) {
        // Save the recipe's name as the favorite food in localStorage
        localStorage.setItem('favoriteFood', recipes[index].name);
    } else {
        // Optional: Clear the favoriteFood if the unfavorited recipe was the one stored
        if (localStorage.getItem('favoriteFood') === recipes[index].name) {
            localStorage.removeItem('favoriteFood'); // Or set to a default or next favorite
        }
    }
    
    loadRecipes(); // Refresh recipe list
    saveRecipes(); // Save updated recipes to localStorage
    
}

function openForm() {
    document.getElementById("myForm").style.display = "block";
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

function addRecipe() {
    var name = document.getElementById('recipeName').value;
    var cookingLevel = document.getElementById('cookingLevel').value;
    var ingredientsDescription = document.getElementById('ingredientsDescription').value;
    var directionsDescription = document.getElementById('directionsDescription').value;
    var cuisine = document.getElementById('recipeCuisine').value;
    var dietaryRestriction = document.getElementById('recipeDietaryRestriction').value;

    if (name && cookingLevel && ingredientsDescription && directionsDescription && cuisine && dietaryRestriction) {
        var cuisineDropdown = document.querySelector('.sort-dropdown');
        var dietaryDropdown = document.querySelector('.dietary-restriction-dropdown');

        // Check if the cuisine is not in the dropdown, then add it
        if (![...cuisineDropdown.options].map(option => option.value.toLowerCase()).includes(cuisine.toLowerCase())) {
            var option = document.createElement('option');
            option.value = cuisine;
            option.text = cuisine;
            cuisineDropdown.appendChild(option);
        }

        // Check if the dietary restriction is not in the dropdown, then add it
        if (![...dietaryDropdown.options].map(option => option.value.toLowerCase()).includes(dietaryRestriction.toLowerCase())) {
            var option = new Option(dietaryRestriction, dietaryRestriction);
            dietaryDropdown.appendChild(option);
        }


        var newRecipe = new Recipe(name, cookingLevel, ingredientsDescription, directionsDescription, cuisine, dietaryRestriction, false); // Default to not favorite
        recipes.push(newRecipe);
        loadRecipes(); // Refresh recipe list to display the new recipe
        saveRecipes(); // Save updated recipes to localStorage
        closeForm(); // Close the form after adding the recipe

        // Clear the form fields
        document.getElementById('recipeName').value = '';
        document.getElementById('cookingLevel').value = '';
        document.getElementById('ingredientsDescription').value = '';
        document.getElementById('directionsDescription').value = '';
        document.getElementById('recipeCuisine').value = '';
        document.getElementById('recipeDietaryRestriction').value = '';

        var recipeList = document.querySelector(".recipe-list");
        recipeList.scrollTo({top:9999,behavior:'smooth'})
    } 
}

function filterRecipes() {
    const cuisineSelection = document.querySelector('.sort-dropdown').value;
    const dietarySelection = document.querySelector('.dietary-restriction-dropdown').value;
    const cookingSelection = document.querySelector('.cooking-level-dropdown').value;

    const recipeList = document.querySelector(".recipe-list");
    recipeList.innerHTML = ''; // Clear current list

    recipes.forEach(function(recipe, index) {
        if ((cuisineSelection === 'all' || recipe.cuisine === cuisineSelection) && 
            (dietarySelection === 'all' || recipe.dietaryRestriction ===
             dietarySelection) && (cookingSelection === 'all' || recipe.cookingLevel == cookingSelection)
              ||( (cuisineSelection === 'favorited' && recipe.favorite === true)
              && (dietarySelection === 'all' || recipe.dietaryRestriction === dietarySelection) && 
              (cookingSelection === 'all' || recipe.cookingLevel == cookingSelection) ) ) {
            var li = document.createElement("li");
            li.className = "recipe-item";
            li.setAttribute("data-index", index);
            li.setAttribute("data-food-type", recipe.cuisine);
            li.setAttribute("data-dietary-restriction-type", recipe.dietaryRestriction);

            var favoriteImage = recipe.favorite ? "img-recipe/star-gold.png" : "img-recipe/star.png";

            li.innerHTML = `
                <h3>${recipe.name}</h3>
                <p><strong>Cooking Level:</strong> ${recipe.cookingLevel}</p>
                <p><strong>Cuisine Type:</strong> ${recipe.cuisine}</p>
                <p><strong>Dietary Restriction:</strong> ${recipe.dietaryRestriction}</p>
                <p><strong>Ingredients:</strong></p>
                <p>${recipe.ingredientsDescription}</p>
                <p><strong>Directions:</strong></p>
                <p>${recipe.directionsDescription}</p>
                <button type="button" class="delete-button" onclick="deleteRecipe(${index})"><img src="img-recipe/trashcan.png" alt="Delete"></button>
                <button type="button" class="favorite-button" onclick="toggleFavorite(${index})"><img src="${favoriteImage}" alt="Favorite Status"></button>
                <button type="button" class="shopping-list-button" onclick="goToShoppingListPage()"><img src="img-recipe/shopping-list-image.png" alt="Shopping List"></button>
            `;
            recipeList.appendChild(li);
        }
    });
}


document.addEventListener("DOMContentLoaded", function() {
    // Your JavaScript code here
    loadRecipes(); // Call the loadRecipes function after the DOM content has loaded
});

document.addEventListener("DOMContentLoaded", function() {
    // Existing DOMContentLoaded code here

    // Toggle for cuisine dropdown
    const cuisineLabel = document.querySelector('.sort-label');
    const cuisineDropdown = cuisineLabel.nextElementSibling; // Assuming dropdown-content is the next sibling

    cuisineLabel.addEventListener('click', function() {
        const currentDisplay = cuisineDropdown.style.display;
        cuisineDropdown.style.display = currentDisplay === 'block' ? 'none' : 'block';
    });

    // Toggle for dietary restrictions dropdown
    const dietaryLabel = document.querySelector('.dietary-restriction-label');
    const dietaryDropdown = dietaryLabel.nextElementSibling; // Assuming dropdown-content is the next sibling

    dietaryLabel.addEventListener('click', function() {
        const currentDisplay = dietaryDropdown.style.display;
        dietaryDropdown.style.display = currentDisplay === 'block' ? 'none' : 'block';
    });

    // Toggle for dietary restrictions dropdown
    const cookingLabel = document.querySelector('.cooking-level-label');
    const cookingDropdown = cookingLabel.nextElementSibling; // Assuming dropdown-content is the next sibling

    cookingLabel.addEventListener('click', function() {
        const currentDisplay = cookingDropdown.style.display;
        cookingDropdown.style.display = currentDisplay === 'block' ? 'none' : 'block';
    });
});
// PERSISTENT STORAGE!!!
// Load recipes from localStorage when the page loads
document.addEventListener("DOMContentLoaded", function() {

    const savedRecipes = localStorage.getItem('recipes');
    console.log("Saved Recipes from localStorage:", savedRecipes);

    if (!savedRecipes || savedRecipes === '[]') {
        console.log("No recipes found in localStorage. Initializing default recipes.");
        // Initialize with default recipes if no recipes are stored
        var PadThai = new Recipe("Pad Thai", "Beginner", "Rice noodles, shrimp, chicken, peanuts, a scrambled egg and bean sprouts.", "Sautée ingredients together in a wok and toss in a delicious Pad Thai sauce.", "Thai", "None", false);
        var margheritaPizza = new Recipe("Pepperoni Pizza", "Beginner", "Cheese, Pizza Dough, Pizza Sauce", "Roll out pizza dough and roll it out. Spread pizza sauce over dough and add cheese with pepperoni dishes. Place in oven set to 350 degrees Fahrenheit for 20 minutes. Enjoy!", "Italian", "Peanut-Free", false);

        recipes.push(PadThai);
        recipes.push(margheritaPizza);
        console.log("Default recipes initialized:", recipes);
        saveRecipes();
    } else {
        recipes = JSON.parse(savedRecipes);
        // Update dropdown menus
        updateDropdownMenus();
    }
    
    updateDietaryRestrictionsDropdown(); // Update dietary restrictions dropdown with user allergies

    loadRecipes(); // Call the loadRecipes function after the DOM content has loaded

    function updateDietaryRestrictionsDropdown() {
        const dietaryDropdown = document.querySelector('.dietary-restriction-dropdown');
        const userAllergy = localStorage.getItem('userAllergy');
    
        if(userAllergy) {
            // Convert userAllergy to a format consistent with the comparison array
            const formattedAllergy = `${userAllergy}`;
            const options = Array.from(dietaryDropdown.options).map(option => option.value.toUpperCase());
            
            // Define allergies that should not be added to the dropdown
            const excludedAllergies = ["VEGAN", "DAIRY", "PEANUT", "PEANUTS", "VEGANISM", "DAIRY-FREE", "VEGAN-FREE", "PEANUT-FREE"];
        
            // Check if the allergy is not in the excluded list and not already in options
            if(!options.includes(formattedAllergy.toUpperCase()) && !excludedAllergies.includes(formattedAllergy.toUpperCase())) {
                const option = new Option(formattedAllergy, formattedAllergy);
                dietaryDropdown.appendChild(option);
            }
        }   
    }
});

// Function to update dropdown menus with Cuisine types and Dietary Restrictions
function updateDropdownMenus() {
    const cuisineDropdown = document.querySelector('.sort-dropdown');
    const dietaryDropdown = document.querySelector('.dietary-restriction-dropdown');

    // Get existing options in dropdown menus
    const existingCuisineOptions = [...cuisineDropdown.options].map(option => option.value.toLowerCase());
    const existingDietaryOptions = [...dietaryDropdown.options].map(option => option.value.toLowerCase());

    // Iterate over recipes to check for new Cuisine types and Dietary Restrictions
    recipes.forEach(recipe => {
        const cuisine = recipe.cuisine.toLowerCase();
        const dietaryRestriction = recipe.dietaryRestriction.toLowerCase();

        // Add new Cuisine type to dropdown if it doesn't exist already
        if (!existingCuisineOptions.includes(cuisine)) {
            const option = document.createElement('option');
            option.value = recipe.cuisine;
            option.text = recipe.cuisine;
            cuisineDropdown.appendChild(option);
            existingCuisineOptions.push(cuisine); // Update existing options array
        }

        // Add new Dietary Restriction to dropdown if it doesn't exist already
        if (!existingDietaryOptions.includes(dietaryRestriction)) {
            const option = new Option(recipe.dietaryRestriction, recipe.dietaryRestriction);
            dietaryDropdown.appendChild(option);
            existingDietaryOptions.push(dietaryRestriction); // Update existing options array
        }
    });
}

// Function to save recipes to localStorage
function saveRecipes() {
    localStorage.setItem('recipes', JSON.stringify(recipes));
    console.log("Recipes saved to localStorage:", recipes);
}