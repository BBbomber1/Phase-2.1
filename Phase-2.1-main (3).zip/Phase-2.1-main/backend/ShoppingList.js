document.addEventListener("DOMContentLoaded", function() {
    var keyboardImage = document.getElementById('keyboardImage');
    const inputFields = document.querySelectorAll('input[type="text"], input[type="number"], textarea');

    inputFields.forEach(field => {
        field.addEventListener('focus', () => {
        document.getElementById('keyboardImage').style.display = 'block';
    });

        // Optional: Hide the keyboard image on blur
        field.addEventListener('blur', () => {
            document.getElementById('keyboardImage').style.display = 'none';
            document.getElementById('formKeyboardImage').style.display = 'none';
        });
    });
});

class ListItem {
    constructor(text, isHighlighted, isStruckThrough, number) {
        this.text = text;
        this.isHighlighted = isHighlighted;
        this.isStruckThrough = isStruckThrough;
        this.number = number;
    }
}

window.onload = function() {
    myOnLoadFunction();
}

function myOnLoadFunction() {
    loadList("shoppingList", "ShoppingList");
    loadDropdownOptions("shoppingListDropdownSelect");
}

window.addEventListener('beforeunload', function(event) {
    // Call your function here
    myWindowUnloadFunction();
});

function myWindowUnloadFunction() {
    saveList("shoppingList", document.getElementById("shoppingListDropdownSelect").value);
    saveDropdownOptions("shoppingListDropdownSelect");
}


function moveToTop(item) {
    var list = document.getElementById("shoppingList");
    list.insertBefore(item, list.firstChild);
}

function strikeThrough(text){
    return text.split('').map(char => char+'\u0336').join('');
}

function unstrikeThrough(text){
    return text.replace(/[\u0336]/g, '');
}


function createTextBox() {
    var item = document.getElementById("itemName").value;
    var quantity = document.getElementById("quantity").value;

    createTextBoxAux1(item, quantity);

    document.getElementById("itemName").value = "";
    document.getElementById("quantity").value = "";
}

function createTextBoxAux1(item, quantity){
    createTextBoxAux(item, quantity, 0, 0);
}

var previousValue = "ShoppingList";

function listChange() {
    var selectElement = document.getElementById("shoppingListDropdownSelect");
    var selectedValue = selectElement.value;

    saveList("shoppingList", previousValue);
    clearList();
    loadList("shoppingList", selectedValue);


    //lastly, update the previous value, this should be done last
    previousValue = selectedValue;
}

function createTextBoxAux(item, quantity, isHighlighted, isStruckThrough) {
    if(item !== '' && quantity !== ''){
        var li = document.createElement("li");

        li.setAttribute('name', item);
        li.setAttribute('isHighlighted', isHighlighted);
        li.setAttribute('isStruckThrough', isStruckThrough);
        li.setAttribute('number', quantity);

        li.style.padding = "5px";
        li.style.fontSize="30px";
        li.style.color = "white";
        li.style.width="98%";

        var textSpanElement = document.createElement("span");
        var textNode = document.createTextNode(item);
        textSpanElement.appendChild(textNode);

        
        var quantityNumber = 0;
        if(parseInt(quantity) < 0) {
            quantityNumber = 0;
        } else if (parseInt(quantity) > 99){
            quantityNumber = 99;
        } else {
            quantityNumber = quantity
        }
        
        var quantityText = document.createTextNode(quantityNumber);

        var spanElement = document.createElement("span");
        spanElement.appendChild(quantityText);
        spanElement.style.float = "right";

        var minusButton = document.createElement("button");
        minusButton.innerHTML = "-";
        minusButton.style.float = "right";
        minusButton.className = "listButton";
        minusButton.onclick = function(){
            if(parseInt(quantityText.textContent) > 0){
                quantityText.textContent = parseInt(quantityText.textContent) - 1;
                li.setAttribute('number', parseInt(quantityText.textContent));
            }
        };
        var plusButton = document.createElement("button");
        plusButton.innerHTML = "+";
        plusButton.style.float = "right";
        plusButton.className = "listButton";
        plusButton.onclick = function(){
            if(parseInt(quantityText.textContent) < 99){
                quantityText.textContent = parseInt(quantityText.textContent) + 1;
                li.setAttribute('number', parseInt(quantityText.textContent));
            }
        };

        var deleteButton = document.createElement("button");
        deleteButton.innerHTML = "×";
        deleteButton.style.float = "right";
        deleteButton.className = "listButton";
        deleteButton.onclick = function(){
            deleteButton.parentNode.remove();
        };

        var alertButton = document.createElement("button");
        alertButton.innerHTML = "!";
        alertButton.style.float = "right";
        alertButton.className = "listButton";
        alertButton.onclick = function(){

            moveToTop(li);
            textSpanElement.style.color = "black";
            li.setAttribute('isHighlighted', 1);
            // textSpanElement.classList.add('highlighted');
            textSpanElement.style.backgroundColor = 'yellow';
        }

        var checkButton = document.createElement("button");
        checkButton.style.float = "right";
        checkButton.innerHTML = "✓";
        checkButton.className = "listButton";
        var isChecked = 0
        checkButton.onclick = function(){
            // if(checkButton.innerHTML.localeCompare("&nbsp;&nbsp;") == 0) {
            if(isChecked == 0){
                // checkButton.innerHTML = "✓";
                isChecked = 1;
                textNode.nodeValue = strikeThrough(textNode.nodeValue);
                li.setAttribute('isStruckThrough', 1);
                // li.style.color = "white";
                // li.style.backgroundColor = "rgb(120, 120, 120)";
            } else{
                // checkButton.innerHTML = "&nbsp;&nbsp;";
                isChecked = 0;
                textNode.nodeValue = unstrikeThrough(textNode.nodeValue);
                li.setAttribute('isStruckThrough', 0);
                // li.style.color = "black"
                // li.style.backgroundColor = "rgb(" + backColor.red + ", " + backColor.blue + ", " + backColor.green + ")";
            }
        };

        // console.log(isHighlighted);
        // console.log(isStruckThrough);

        if(isHighlighted == 1){
            textSpanElement.classList.add("highlight");
            textSpanElement.style.color = "black";
        }

        if(isStruckThrough == 1){
            isChecked = 1;
            textNode.nodeValue = strikeThrough(textNode.nodeValue);
        }


        li.appendChild(textSpanElement);
        li.appendChild(deleteButton);
        li.appendChild(alertButton);
        li.appendChild(checkButton);
        li.appendChild(plusButton);
        li.appendChild(spanElement); //this adds the quantity text
        li.appendChild(minusButton);


        document.getElementById("shoppingList").appendChild(li);
        
    }
}



function convertToItem(listItem){
    text = listItem.getAttribute('name');
    isHighlighted = listItem.getAttribute('isHighlighted');
    isStruckThrough = listItem.getAttribute('isStruckThrough');
    number = listItem.getAttribute('number');

    return new ListItem(text, isHighlighted, isStruckThrough, number);
}

function addSavedItemToList(savedItem){
    createTextBoxAux(savedItem.text, savedItem.number, savedItem.isHighlighted, savedItem.isStruckThrough);
}

//ShoppingList is the name of the default list (listName)
//default list is named ShoppingList
function saveList(listId, listName) {
    const list = document.getElementById(listId)
    if(list) {
        const items = [];
        const listItems = list.getElementsByTagName('li');
        for (let i = 0; i < listItems.length; i++) {
            items.push(convertToItem(listItems[i]));
        }

        localStorage.setItem('shoppingList' + listName, JSON.stringify(items));

        console.log('list saved to local storage ' + 'shoppingList' + listName);
    } else {
        console.error('List with provided id not found.');
    }
}

function loadList(listId, listName) {
    // console.log('shoppingList' + listName);
    const savedList = localStorage.getItem('shoppingList' + listName);
    if(savedList) {
        const items = JSON.parse(savedList);
        const list = document.getElementById(listId);
        if(list) {
            while(list.firstChild ){
                list.removeChild(list.firstChild );
            }//remove all items in list, I think
            
            items.forEach(item => {
                addSavedItemToList(item);
            });
            console.log('List loaded from local storage' + 'shoppingList' + listName);
        } else {
            console.error('list with provided id not found');
        }
    } else {
        console.error('no saved list found in local storage');
    }
}

function addListToCurrentList(listId, listToLoadFrom) {
    const savedList = localStorage.getItem('shoppingList' + listToLoadFrom);
    if(savedList) {
        const items = JSON.parse(saveList);
        const list = document.getElementById(listId);
        if(list) {
            items.forEach(item => {
                addSavedItemToList(item);
            });
            console.log('List loaded from local storage');
        } else {
            console.error('list with provided id not found');
        }
    } else {
        console.error('no saved list found in local storage');
    }
}

function transferAllListItems(listId, listToLoadFrom, listToLoadTo) {
    const listFrom = localStorage.getItem('shoppingList' + listToLoadFrom);
    const listTo = localStorage.getItem('shoppingList' + listToLoadTo);
    if(listFrom && listTo) {
        itemsFrom = JSON.parse(listFrom);
        itemsTo = JSON.parse(listTo);
        if(itemsFrom && itemsTo) {
            itemsFrom.forEach(singleItem => {
                itemsTo.push(singleItem);
            });
            localStorage.setItem('shoppingList' + 'ShoppingList', JSON.stringify(itemsTo));
            console.log('Transferred items from ' + listToLoadFrom + ' to ' + listToLoadTo);
        } else {
            console.error('list with provided id not found in transferAllListItems')
        }
    } else {
        console.error('list not found in local storage in transferAllListItems');
    }
}

function transferAllButtonClick(){
    console.log("transfer button click");
    saveList("shoppingList", document.getElementById("shoppingListDropdownSelect").value);
    transferAllListItems("shoppingList", document.getElementById("shoppingListDropdownSelect").value, "ShoppingList")
}

//use this to add items to a list that is currently saved in memory
//default list is named ShoppingList
function addOneItemToList(itemName, itemNumber, listName) {
    
    const savedList = localStorage.getItem('shoppingList' + listName);
    
    if(savedList) {
        
        const items = JSON.parse(savedList);
        // console.log("got here");
        const newItems = [];
        for(let i = 0; i < items.length; i++){
            newItems.push(new ListItem(items.text, items.number, items.isHighlighted, items.isStruckThrough));
        }
        newItems.push(new ListItem(itemName, '' + itemNumber, '0', '0'));
        localStorage.setItem('shoppingList' + listName, JSON.stringify(newItems));
        // console.log(items);
        console.log('shoppingList' + listName);
        
        console.log('list saved to local storage' + newItems.length);
    }
    
}

//adds a new item to the shopping list dropdown menu
function addNewList() {
    const newItemInput = document.getElementById('newShoppingList');
    const newItemValue = newItemInput.value.trim();
    if (newItemValue !== ''){
        const dropdownMenu = document.getElementById('shoppingListDropdownSelect');
        const option = document.createElement('option');
        option.value = newItemValue;
        option.textContent = newItemValue;
        dropdownMenu.appendChild(option);
        newItemInput.value = ''; //clear inputt field after adding item
    }
}

//saves a list of the shopping lists
function saveDropdownOptions(dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    
    if(dropdown) {
        const itemsSave = [];
        const dropdownItems = dropdown.getElementsByTagName('option');
        for(let i = 0; i < dropdownItems.length; i++) {
            itemsSave.push(dropdownItems[i].value);
        }
        localStorage.setItem('shoppingListItemsSave' + dropdownId, JSON.stringify(itemsSave));
        console.log('dropdown options saved to local storage');
    } else {
        console.error('dropdown options saving errored')
    }
}

function loadDropdownOptions(dropdownId) {
    const savedOptions = localStorage.getItem('shoppingListItemsSave' + dropdownId);
    if(savedOptions) {
        const options = JSON.parse(savedOptions);
        const dropdown = document.getElementById(dropdownId)
        if (dropdown) {
            dropdown.innerHTML = '';
            options.forEach(option => {
                const newOption = document.createElement('option');
                newOption.value = option;
                newOption.textContent = option;
                dropdown.appendChild(newOption);
            });
            console.log('dropdown options loaded from local storage');
        } else {
            console.error('dropdown with provided id not found');
        }
    } else {
        console.error('no saved options found in local storage');
    }
}

function clearList() {
    list = document.getElementById("shoppingList");
    list.innerHTML = '';
}