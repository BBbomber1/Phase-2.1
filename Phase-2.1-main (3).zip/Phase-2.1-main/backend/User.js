    document.addEventListener("DOMContentLoaded", function() {
        var usernameInput = document.getElementById('username');
        var message = document.getElementById('usernameValidationMessage');

        usernameInput.addEventListener('focus', function() {
            message.style.display = 'block'; // Show message
        });

        usernameInput.addEventListener('blur', function() {
            message.style.display = 'none'; // Hide message
        });

        // Load data from localStorage and populate form fields
        var savedUsername = localStorage.getItem('username');
        var savedCookingSkill = localStorage.getItem('cookingSkill');
        var savedFavoriteFood = localStorage.getItem('favoriteFood');

        if (savedUsername) {
            document.getElementById('username').value = savedUsername;
        }

        if (savedCookingSkill) {
            document.getElementById('cookingSkill').value = savedCookingSkill;
        }

        if (savedFavoriteFood) {
            document.getElementById('favoriteFood').value = savedFavoriteFood;
        }
    });

    document.getElementById('userForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission behavior

        // Extract form values
        var username = document.getElementById('username').value;
        var cookingSkill = document.getElementById('cookingSkill').value;
        var favoriteFood = document.getElementById('favoriteFood').value;

        // Save data to localStorage
        localStorage.setItem('username', username);
        localStorage.setItem('cookingSkill', cookingSkill);
        localStorage.setItem('favoriteFood', favoriteFood);


        // Construct the message
        var message = "Hey there! I'm using the Kitchen Kompanion app and my username is @" + username +
                    " and my cooking skill is " + cookingSkill + ". My favorite food is " + "\"" + favoriteFood + "\"" +
                    ", come join me on the Kitchen Kompanion app so we can talk about our favorite foods!";

        // Display the message
        var outputMessage = document.getElementById('outputMessage');
        outputMessage.innerText = message;

        // Show the copy button
        var copyButton = document.getElementById('copyButton');
        copyButton.style.display = 'block';

        // Copy to clipboard function
        copyButton.onclick = function() {
            navigator.clipboard.writeText(outputMessage.innerText).then(() => {
                // Success message
                var copySuccess = document.getElementById('copySuccess');
                copySuccess.innerText = 'Copied to your clipboard!';
                copySuccess.style.display = 'block';
            }).catch(err => {
                console.error('Error in copying text: ', err);
            });
        };
    });
