# Phase-2.1

Link to project description: [https://docs.google.com/document/d/12nEoEkxHRJ-xYVbAo1YZ6BrQ7StMTYFWcf9O1HdcahU/edit?usp=sharing](https://docs.google.com/document/d/12nEoEkxHRJ-xYVbAo1YZ6BrQ7StMTYFWcf9O1HdcahU/edit?usp=sharing)
